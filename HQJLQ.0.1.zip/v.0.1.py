from bs4 import BeautifulSoup as bs
import requests
import os
import sys
import time
import webbrowser
import shutil  # Klasörleri silmek için

def get_soup(url):
    return bs(requests.get(url).text, 'html.parser')

def indirme_islemi():
    DOMAIN = 'https://www.mediafire.com/'
    URL = 'https://www.mediafire.com/file/ui5bnyvjvoao2n6/HQJLQ.exe'
    FILETYPE = '.exe'
    
    for link in get_soup(URL).find_all('a'):
        file_link = link.get('href')
        if FILETYPE in file_link:
            file_name = file_link.split('/')[-1]
            print(file_name)
            # Dosya varsa sil
            if os.path.exists(file_name):
                os.remove(file_name)
                print("Önceki dosya silindi:", file_name)
            with open(file_name, 'wb') as dosya_objesi:
                response = requests.get(file_link, stream=True)
                for veri in response.iter_content(chunk_size=1024):
                    dosya_objesi.write(veri)
                    sys.stdout.write("\rİndiriliyor...")
                    sys.stdout.flush()
                print("\nİndirme tamamlandı!")
            
            # İndirme işlemi tamamlandıktan sonra "File" adlı dosya veya klasörü sil
            if os.path.exists("File"):
                if os.path.isfile("File"):
                    os.remove("File")
                    print("File dosyası silindi.")
                elif os.path.isdir("File"):
                    shutil.rmtree("File")
                    print("File klasörü silindi.")
                else:
                    print("File bir dosya veya klasör değil.")

def discord_yonlendir():
    webbrowser.open_new_tab("https://discord.gg/fAmRnNc2")  # Discord'u açar

def sitem_yonlendir():
    webbrowser.open_new_tab("https://discord.gg/fAmRnNc2")  # Sitenizi açar

def duskmt2_indir():
    DOMAIN = 'https://www.mediafire.com/'
    URL = 'https://www.mediafire.com/file/0g4d09pnd6vrqau/metin2client.bin'
    FILETYPE = '.bin'
    
    for link in get_soup(URL).find_all('a'):
        file_link = link.get('href')
        if FILETYPE in file_link:
            file_name = file_link.split('/')[-1]
            print(file_name)
            # Dosya varsa sil
            if os.path.exists(file_name):
                os.remove(file_name)
                print("Önceki dosya silindi:", file_name)
            with open(file_name, 'wb') as dosya_objesi:
                response = requests.get(file_link, stream=True)
                for veri in response.iter_content(chunk_size=1024):
                    dosya_objesi.write(veri)
                    sys.stdout.write("\rİndiriliyor...")
                    sys.stdout.flush()
                print("\nİndirme tamamlandı!")

            # İndirme işlemi tamamlandıktan sonra "File" adlı dosya veya klasörü sil
            if os.path.exists("File"):
                if os.path.isfile("File"):
                    os.remove("File")
                    print("File dosyası silindi.")
                elif os.path.isdir("File"):
                    shutil.rmtree("File")
                    print("File klasörü silindi.")
                else:
                    print("File bir dosya veya klasör değil.")

def kategori_secimi():
    print("1. Doğu2 Vs'lik")
    print("2. Doğu2 Mini Hile(YAKINDA)")
    print("3. DuskMt2 Vs'lik")
    print("4. DuskMt2 Mini Hile(YAKINDA)")
    print("5. Discord'a Yönlendirme")
    print("6. Siteye Yönlendirme")
    secim = input("Lütfen bir kategori seçin (İstediğiniz Server Varsa Discord İsim Ve Site Link'i Bırakmanız Yeterlidir.):")
    if secim == "1":
        indirme_islemi()
    elif secim == "3":
        duskmt2_indir()
    elif secim == "5":
        discord_yonlendir()
    elif secim == "6":
        sitem_yonlendir()
    else:
        print("Geçersiz seçim!")

kategori_secimi()

input("Programı kapatmak için Enter'a basın...")
